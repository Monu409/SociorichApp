package com.app.sociorichapp.modals;

public class CommentModal {
    private String comntStr;

    public String getComntStr() {
        return comntStr;
    }

    public void setComntStr(String comntStr) {
        this.comntStr = comntStr;
    }
}
