package com.app.sociorichapp.modals;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.app.sociorichapp.R;
import com.app.sociorichapp.activities.BaseActivity;
import com.app.sociorichapp.activities.CreateAccActivity;
import com.app.sociorichapp.activities.DashboardActivity;
import com.app.sociorichapp.activities.ForgetPassword;
import com.app.sociorichapp.activities.StringRequestCustom;
import com.app.sociorichapp.app_utils.ConstantMethods;
import com.app.sociorichapp.app_utils.UserRequestCustom;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.app.sociorichapp.app_utils.AppApis.BASE_URL;


public class LoginActivity extends BaseActivity {
    EditText email, password;
    String url = BASE_URL + "oauth/token";
    String purl = BASE_URL + "api/v1/user/currentuserprofile";
    static public String username, coverpic, profilepic, socialmoneybalance, equamoneybalance, identity;
    ProgressDialog dialog;
    private TextView forgotText;
    //  public MyDialog dialog;
    Context context;
    StringRequestCustom stringRequest;
    StringRequestCustom stringRequest1;
    private RequestQueue requestQueue;
    //private String TAG = JsonRequestActivity.class.getSimpleName();
    UserRequestCustom stringRequest12;
    private ProgressDialog pDialog;

    // These tags will be used to cancel the requests
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private TextView createAccTxt;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Login");
        email = (EditText) findViewById(R.id.email_edt);
        password = (EditText) findViewById(R.id.password_edt);
        createAccTxt = findViewById(R.id.create_acc_txt);
        pDialog = new ProgressDialog(this);
        forgotText = findViewById(R.id.forgot_txt);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
        //Context.context=this.context;
        Button loginBtn = findViewById(R.id.login_btn);
        loginBtn.setOnClickListener(v -> {
            UserLogin();
        });
        forgotText.setOnClickListener(v -> startActivity(new Intent(this, ForgetPassword.class)));
        createAccTxt.setOnClickListener(v->startActivity(new Intent(this, CreateAccActivity.class)));
    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_login;
    }

    public void UserLogin() {
        if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
        } else {
            verifyCode();
        }

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.hide();
    }

    private void verifyCode() {
        //   dialog.ShowProgressDialog();
        if (requestQueue == null) {
            dialog = new ProgressDialog(LoginActivity.this);
            dialog.setMessage("please wait");
            dialog.show();
            dialog.setCancelable(false);
            requestQueue = Volley.newRequestQueue(LoginActivity.this);
        }
        stringRequest = new StringRequestCustom(LoginActivity.this, Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    dialog.dismiss();
                    //  dialog.CancelProgressDialog();
                    JSONObject obj = new JSONObject(response);
                    String accesstoken = obj.getString("access_token");
                    String token_type = obj.getString("access_token");
                    String refresh_token = obj.getString("refresh_token");
                    ConstantMethods.setStringPreference("login_status", "login", LoginActivity.this);
                    ConstantMethods.setStringPreference("user_token", accesstoken, LoginActivity.this);
//                    User_Profile.usertoken=accesstoken;
//                    Methods.saveAccessToken(LoginActivity.this,accesstoken);
//                    Methods.saveTokenRefresh(LoginActivity.this,refresh_token);
//                    Methods.saveSession(LoginActivity.this,"true");
                    verifyCode_user();
                    /*if (error.equals("true")) {*/


                    //  Toast.makeText(getApplicationContext(), error, Toast.LENGTH_LONG).show();


                   /* } else {
                       // TastyToast.makeText(getApplicationContext(), obj.getString("msg"), TastyToast.LENGTH_LONG, TastyToast.ERROR);
                        Toast.makeText(getApplicationContext(), obj.getString("msg"), Toast.LENGTH_LONG).show();
                    }*/
                } catch (JSONException e) {
                    dialog.dismiss();
                    Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                // VolleyLog.d(TAG, "Error: " + error.getMessage());
                // dialog.CancelProgressDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("grant_type", "password");
                params.put("username", email.getText().toString());
                params.put("password", password.getText().toString());
                Log.e("params", String.valueOf(params));
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }

    private void verifyCode_user() {
        //   dialog.ShowProgressDialog();
        if (requestQueue == null) {
            dialog = new ProgressDialog(LoginActivity.this);
            dialog.setMessage("please wait");
            dialog.show();
            dialog.setCancelable(false);
            requestQueue = Volley.newRequestQueue(LoginActivity.this);
        }
        stringRequest12 = new UserRequestCustom(LoginActivity.this, Request.Method.GET, purl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    dialog.dismiss();
                    //  dialog.CancelProgressDialog();
                    JSONObject ob1j = new JSONObject(response);
                    username = ob1j.getString("displayName");
                    identity = ob1j.getString("identity");


                    ConstantMethods.saveUserID(LoginActivity.this, identity);
                    //   Toast.makeText(getApplicationContext(),"Invalid username or password-2289",Toast.LENGTH_SHORT).show();
                    Intent intent_call = new Intent(LoginActivity.this, DashboardActivity.class);
                    intent_call.addFlags(intent_call.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent_call);

                } catch (JSONException e) {
                    Intent intent_call = new Intent(LoginActivity.this, DashboardActivity.class);
                    intent_call.addFlags(intent_call.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent_call);
                    // Toast.makeText(getApplicationContext(),"Invalid username or password---111",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Intent intent_call = new Intent(LoginActivity.this, DashboardActivity.class);
                intent_call.addFlags(intent_call.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent_call);
                //  Toast.makeText(getApplicationContext(),"Invalid username or password-222",Toast.LENGTH_SHORT).show();
                // VolleyLog.d(TAG, "Error: " + error.getMessage());
                // dialog.CancelProgressDialog();
            }
        }) {
        }

        ;

        stringRequest12.setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest12);
    }
}
