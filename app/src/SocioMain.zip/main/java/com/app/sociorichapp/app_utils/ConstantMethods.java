package com.app.sociorichapp.app_utils;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by PC on 7/1/2019.
 */

public class ConstantMethods {
    public static ProgressDialog progressDialog;
    public static void setTitleAndBack(AppCompatActivity activity,String title){
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        activity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        activity.setTitle(title);
    }

    public static void showProgressbar(Context context){
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(true);
        progressDialog.show();
    }
    public static void dismissProgressBar(){
        progressDialog.dismiss();
    }
    public static boolean saveAccessToken(Context context, String token){
        SharedPreferences sharedPreferences=getPreferances(context);
        return sharedPreferences.edit().putString("token",token).commit();
    }
    public static String getAccessToken(Context context){
        SharedPreferences sharedPreferences=getPreferances(context);
        return sharedPreferences.getString("token", null);
    }
    public  static SharedPreferences getPreferances(Context context){
        return context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);

    }
    public static boolean saveUserID(Context context, String UserID){
        SharedPreferences sharedPreferences=getPreferances(context);
        return sharedPreferences.edit().putString("UserID",UserID).commit();
    }
    public static String getUserID(Context context){
        SharedPreferences sharedPreferences=getPreferances(context);
        return sharedPreferences.getString("UserID", null);
    }
    public static void setStringPreference(String key, String value, Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getStringPreference(String key, Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString(key, "");
    }

    public static String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        String date = DateFormat.format("dd/MM/yyyy", cal).toString();
        return date;
    }

    public static String currentDate(){
        Date d = new Date();
        CharSequence s  = DateFormat.format("dd/MM/yyyy", d.getTime());
        return String.valueOf(s);
    }

    public static void saveArrayListShared(List<String> list, Context context,String key){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!
    }

    public static List<String> getArrayListShared(Context context,String key){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        return gson.fromJson(json, type);
    }
}
