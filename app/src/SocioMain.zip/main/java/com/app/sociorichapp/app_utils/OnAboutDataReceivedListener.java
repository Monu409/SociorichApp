package com.app.sociorichapp.app_utils;

public interface OnAboutDataReceivedListener {
    void onDataReceived(String intro, String workSpc, String location, String dob);
}
