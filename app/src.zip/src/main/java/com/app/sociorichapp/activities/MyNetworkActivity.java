package com.app.sociorichapp.activities;

public class MyNetworkActivity {
}
