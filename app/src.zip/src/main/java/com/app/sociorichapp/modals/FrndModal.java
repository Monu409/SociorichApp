package com.app.sociorichapp.modals;

public class FrndModal {
    private String fNameStr;
    private String imgUrl;
    private String identity;
    private String friendStatus;

    public String getfNameStr() {
        return fNameStr;
    }

    public void setfNameStr(String fNameStr) {
        this.fNameStr = fNameStr;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getFriendStatus() {
        return friendStatus;
    }

    public void setFriendStatus(String friendStatus) {
        this.friendStatus = friendStatus;
    }
}
