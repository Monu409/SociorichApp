package com.app.sociorichapp.modals;

public class NetworkModal {
    private String profileStr;
    private String nameStr;
    private String socioStr;

    public String getProfileStr() {
        return profileStr;
    }

    public void setProfileStr(String profileStr) {
        this.profileStr = profileStr;
    }

    public String getNameStr() {
        return nameStr;
    }

    public void setNameStr(String nameStr) {
        this.nameStr = nameStr;
    }

    public String getSocioStr() {
        return socioStr;
    }

    public void setSocioStr(String socioStr) {
        this.socioStr = socioStr;
    }
}
